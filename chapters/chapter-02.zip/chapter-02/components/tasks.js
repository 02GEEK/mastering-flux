import React from 'react';

export default class Tasks extends React.Component{
	render(){
		return <span>Hello world 3.4</span>;
	}
}